window.onload = function() { 

	const ALUMNO = "Andrea Guardia";

	console.log("Datos iniciales");
	console.table(proyectos);		
		
	
}


